<?php

namespace ActionTest;

class Plugin
{

    public function sayHi(): string
    {
        return  'Hi Roy';
    }
}
